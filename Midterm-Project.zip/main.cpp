#include <iostream>
#include <string>
using namespace std;

struct Factors {
    string name;
    int age;
    string major;
    string classification;
};


char getJobs (char);
char getHousing(int);


int main() {
    int enterName
 }