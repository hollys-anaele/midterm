#include <iostream>
#include <string>
using namespace std;

struct Factors {
    string name;
    int age;
    string major;
    string classification;
};


void getUser(Factors &fact);

void getHousing(Factors &fact);

void getScholarship(Factors &fact);

int main() {
    string option;

    Factors f;
    cout << "Welcome to the Database! This application allows you to search for scholarships or housing for college students planning to attend Morgan State University. \n";
    getUser(f);

    cout << "Would you like to find housing, or search for scholarships? (type H for housing, or S for scholarships \n";

    cin >> option;

    if (option == "H"){
        getHousing(f);
    }
    if (option == "S"){
        getScholarship(f);
    }
    return 0;

 }

void getUser(Factors &fact) {
    cout << "Enter name: \n";
    cin >> fact.name;
    cout << "Enter age: \n";
    cin >> fact.age;
    cout << "What is your classification? (either Freshman, Sophomore, Junior, Senior) \n";
    cin >> fact.classification;
    cout << "Enter a major (either Biology, Math, Engineering, or Computer Science) \n";
    cin >> fact.major;
}

void getHousing(Factors &fact) {
    if (fact.age < 18) {
        cout << "You cannot get any housing unless you are above the age of 18.";
    } else {
        cout<< "Here are some available locations:" << endl;
        cout<< "Morgan View: https://www.morganview.com/student-apartments/md/baltimore/morgan-view" << endl;
        cout<< "Marble Hall Gardens: http://mhgardens.com/" << endl;
        cout<< "Barclay Square Apartments: https://www.thebarclaysquareapts.com/" << endl;
    }
    }

void getScholarship(Factors &fact) {
    if (fact.major == "Biology") {
        if (fact.classification == "Freshman") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Natural Resources Excellence in Education Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/natural-resources-excellence-in-education/" << endl;
            cout<< "Scarlett Family Foundation Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/scarlett-family-foundation-scholarship/" << endl;
            cout<< "Maureen D.Keller Undergraduate Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/the-maureen-d-keller-undergraduate-scholarship/" << endl;
        } if (fact.classification == "Sophomore") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Clarkston Scholars Program: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/clarkston-scholars-program/" << endl;
            cout<< "EPP Undergraduate Scholarship Program: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/epp-undergraduate-scholarship-program/" << endl;
            cout<< "Murphy Memorial Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/murphy-memorial-scholarship/" << endl;
        } if (fact.classification == "Junior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Alabama Environmental Health Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/alabama-environmental-health-association-scholarship/" << endl;
            cout<< "Elmhurst Garden Club Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/elmhurst-garden-club-scholarship/" << endl;
        } if (fact.classification == "Senior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Robert Noyce Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/the-robert-noyce-scholarship/" << endl;
            cout<< "Psgc Undergradute Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/psgc-undergraduate-scholarship/" << endl;



        }
        }
    if (fact.major == "Math") {
        if (fact.classification == "Freshman") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Scarlett Family Foundation Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/math-scholarships/scarlett-family-foundation-scholarship/" << endl;
            cout<< "UW Stout Polytechnic Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/math-scholarships/uw-stout-polytechnic-scholarship/" << endl;
        } if (fact.classification == "Sophomore") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Jesse L Jackson Fellows Toyota Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/math-scholarships/jesse-l-jackson-fellows-toyota-scholarship/" << endl;
            cout<< "EPP Undergraduate Scholarship Program: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/epp-undergraduate-scholarship-program/" << endl;
        } if (fact.classification == "Junior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Jsu Alabama Bush Memorial Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/math-scholarships/jsu-alabama-bush-memorial-scholarship/" << endl;
            cout<< "Whoi Summer Student Fellowship Program: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/math-scholarships/whoi-summer-student-fellowship-program/" << endl;
        } if (fact.classification == "Senior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Whoi Summer Student Fellowship Program: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/math-scholarships/whoi-summer-student-fellowship-program/"<< endl;


            
        }
        }

    if (fact.major == "Engineering") {
        if (fact.classification == "Freshman") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Ams Freshman Undergraduate Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/engineering-scholarships/ams-freshman-undergraduate-scholarship/" << endl;
            cout<< "ANS Incoming Freshman Scolarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/engineering-scholarships/ans-incoming-freshman-scholarship/" << endl;
        } if (fact.classification == "Sophomore") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Clarkston Scholars Program: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/clarkston-scholars-program/" << endl;
            cout<< "Yards and Terminals Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/engineering-scholarships/committee-14-yards-and-terminals-scholarship/" << endl;
            cout<< "Ray Greenly Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/engineering-scholarships/ray-greenly-scholarship/" << endl;
        } if (fact.classification == "Junior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Ray Greenly Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/engineering-scholarships/ray-greenly-scholarship/" << endl;
            cout<< "SMRP Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/engineering-scholarships/smrp-scholarship/" << endl;
        } if (fact.classification == "Senior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "SMRP Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/engineering-scholarships/smrp-scholarship/" << endl;
            cout<< "Union Pacific William E Wimmer Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/engineering-scholarships/union-pacific-william-e-wimmer-scholarship/" << endl;



        }
        }
    if (fact.major == "Computer Science") {
        if (fact.classification == "Freshman") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Dean's Computer Science Freshman Scholarship: https://www.binghamton.edu/financial-aid/types-of-aid/scholarships/index.html" << endl;
        } if (fact.classification == "Sophomore") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Future Engineers Scholars Program: https://www.kellyservices.us/US/Careers/Kelly-Engineering-Resources/Future-Engineers-Scholarship-Program/#.VdIpSBjBzRZ" << endl;
        } if (fact.classification == "Junior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Future Engineers Scholars Program: https://www.kellyservices.us/US/Careers/Kelly-Engineering-Resources/Future-Engineers-Scholarship-Program/#.VdIpSBjBzRZ" << endl;
            cout<< "Barry Goldwater Scholarship: https://goldwater.scholarsapply.org/yybull.php" << endl;
        } if (fact.classification == "Senior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Barry Goldwater Scholarship: https://goldwater.scholarsapply.org/yybull.php" << endl;

            
        }
        }
    }
