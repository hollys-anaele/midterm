#include <iostream>
#include <string>
using namespace std;

struct Factors {
    string name;
    int age;
    string major;
    string classification;
};




int main() {

 }

void getUser(Factors &fact) {
    cout << "Enter name: ";
    cin >> fact.name;
    cout << "Enter age: ";
    cin>> fact.age;
    cout<< "What is your classification? (either Freshman, Sophomore, Junior, Senior";
    cin>> fact.classification;
    cout << "Enter a major (either Biology, Math, Engineering, or Computer Science";
    cin >> fact.major;
}

void getHousing(Factors &fact) {
    if (fact.age < 18) {
        cout << "You cannot get any housing unless you are above the age of 18.";
    } else {
        cout<< "Here are some available locations:" << endl;
        cout<< "Morgan View: https://www.morganview.com/student-apartments/md/baltimore/morgan-view" << endl;
        cout<< "Marble Hall Gardens: http://mhgardens.com/" << endl;
        cout<< "Barclay Square Apartments: https://www.thebarclaysquareapts.com/" << endl;
    }
    }

void getScholarship(Factors fact) {
    if (fact.major == "Biology") {
        if (fact.classification == "Freshman") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Natural Resources Excellence in Education Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/natural-resources-excellence-in-education/" << endl;
            cout<< "Scarlett Family Foundation Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/scarlett-family-foundation-scholarship/" << endl;
            cout<< "Maureen D.Keller Undergraduate Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/the-maureen-d-keller-undergraduate-scholarship/" << endl;
        } if (fact.classification == "Sophomore") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Clarkston Scholars Program: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/clarkston-scholars-program/" << endl;
            cout<< "EPP Undergraduate Scholarship Program: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/epp-undergraduate-scholarship-program/" << endl;
            cout<< "Murphy Memorial Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/murphy-memorial-scholarship/" << endl;
        } if (fact.classification == "Junior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Alabama Environmental Health Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/alabama-environmental-health-association-scholarship/" << endl;
            cout<< "Elmhurst Garden Club Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/elmhurst-garden-club-scholarship/" << endl;
        } if (fact.classification == "Senior") {
            cout << "Here are some scholarships for you: " << endl;
            cout<< "Robert Noyce Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/the-robert-noyce-scholarship/" << endl;
            cout<< "Psgc Undergradute Scholarship: https://www.scholarships.com/financial-aid/college-scholarships/scholarships-by-major/biology-scholarships/psgc-undergraduate-scholarship/" << endl;

        }
        }
    }
}